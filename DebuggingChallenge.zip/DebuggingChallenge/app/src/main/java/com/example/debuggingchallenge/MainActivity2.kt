package com.example.debuggingchallenge

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import androidx.core.view.isVisible

class MainActivity2 : AppCompatActivity() {

     var users2 = arrayListOf(String)
    private lateinit var activeUsers: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        var intent = intent
        var users=intent.getStringArrayListExtra("users2")

        activeUsers = findViewById(R.id.tvActiveUsers)



        var allUsers = "Active Users:\n\n"
        if (users != null) {
            for(user in users){
                allUsers += "$user \n"
            }
        }
        activeUsers.text = allUsers
        activeUsers.isVisible = true
    }


}