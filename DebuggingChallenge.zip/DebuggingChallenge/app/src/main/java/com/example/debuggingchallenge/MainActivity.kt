package com.example.debuggingchallenge

import android.content.Intent
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import androidx.core.view.isVisible

class MainActivity : AppCompatActivity() {
    private lateinit var llMain: LinearLayout
    private lateinit var userName: EditText
    private lateinit var password: EditText
    private lateinit var password2: EditText
    private lateinit var submitBtn: Button
    private lateinit var noNumber:TextView
    private lateinit var chrNum:TextView
    private lateinit var specialChr:TextView

    private var users = arrayListOf(
        "Freddy",
        "Jason",
        "Ripley",
        "Poncho",
        "Saitama",
        "Archer",
        "Derek",
        "Pamela",
        "Simba",
        "Simon",
        "Retsy",
        "Peter",
        "Daria",
        "Smitty"
    )


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        llMain = findViewById(R.id.llMain)
        userName = findViewById(R.id.etUsername)
        password = findViewById(R.id.etPassword)
        password2 = findViewById(R.id.etConfirmPassword)
        submitBtn = findViewById(R.id.btSubmit)



        submitBtn.setOnClickListener {
            if(usernameAccepted(userName.text.toString()) && passwordAccepted(password.text.toString() ,password2.text.toString())){
                Toast.makeText(this, "User created!", Toast.LENGTH_LONG).show()


                users.add(userName.text.toString().capitalize())


                val intent= Intent(this, MainActivity2::class.java)
                intent.putExtra("users2",users)

                startActivity(intent)



            }
        }

    }

    private fun usernameAccepted(text: String): Boolean{

        specialChr =findViewById(R.id.specialChr)
        noNumber =findViewById(R.id.noNumber)
        chrNum =findViewById(R.id.chrNum)


        if(text in users){
            Toast.makeText(this, "The username is already taken", Toast.LENGTH_LONG).show()
            return false
        }else if(text.length <5 || text.length > 15){
            chrNum.setTextColor(Color.RED)
            Toast.makeText(this, "The username must be between 5 and 15 characters long", Toast.LENGTH_LONG).show()
            return false
        }else if(hasNumber(text)){

            noNumber.setTextColor(Color.RED)
            Toast.makeText(this, "The username cannot contain numbers", Toast.LENGTH_LONG).show()
            return false
        }else if(hasSpecial(text) && !text.contains(" ")){
            specialChr.setTextColor(Color.RED)
            Toast.makeText(this, "The username cannot contain special characters or spaces", Toast.LENGTH_LONG).show()
            return false
        }


        return true

///
       /* if(text !in users){
            if(text.length in 5..15){
                if(!hasNumber(text)){
                    if(!hasSpecial(text) && !text.contains(" ")){
                        return true

                    }
                    specialChr.setTextColor(Color.RED)
                    Toast.makeText(this, "The username cannot contain special characters or spaces", Toast.LENGTH_LONG).show()

                }

                noNumber.setTextColor(Color.RED)
                Toast.makeText(this, "The username cannot contain numbers", Toast.LENGTH_LONG).show()
            }


            chrNum.setTextColor(Color.RED)
            Toast.makeText(this, "The username must be between 5 and 15 characters long", Toast.LENGTH_LONG).show()




        }

       // specialChr.setTextColor(Color.parseColor("#808080"))
       // noNumber.setTextColor(Color.parseColor("#808080"))
       /// chrNum.setTextColor(Color.parseColor("#808080"))

        Toast.makeText(this, "The username is already taken", Toast.LENGTH_LONG).show()
        return false*/





    }

    private fun passwordAccepted(text: String ,text2: String): Boolean{

        if(text.length < 8){

            Toast.makeText(this, "The password must be at least 8 characters long", Toast.LENGTH_LONG).show()
            return false
        }else if(!hasUpper(text)){
            Toast.makeText(this, "The password must contain an uppercase letter", Toast.LENGTH_LONG).show()
            return false
        }else if(!hasNumber(text)){
            Toast.makeText(this, "The password must contain a number", Toast.LENGTH_LONG).show()
            return false
        }else if(!hasSpecial(text)){
            Toast.makeText(this, "The password must contain a special character", Toast.LENGTH_LONG).show()
            return false
        }else if(text!=text2){
            Toast.makeText(this, "The password must be Confirmed ", Toast.LENGTH_LONG).show()
            return false
        }


        return true





     /*   if(text.length >= 8){
            if(hasUpper(text)){
                if(hasNumber(text)){
                    if(hasSpecial(text)){
                        if(text==text2){
                        return true
                        }
                        Toast.makeText(this, "The password must be Confirmed ", Toast.LENGTH_LONG).show()
                    }
                    Toast.makeText(this, "The password must contain a special character", Toast.LENGTH_LONG).show()
                }
                Toast.makeText(this, "The password must contain a number", Toast.LENGTH_LONG).show()
            }
            Toast.makeText(this, "The password must contain an uppercase letter", Toast.LENGTH_LONG).show()
        }
        Toast.makeText(this, "The password must be at least 8 characters long", Toast.LENGTH_LONG).show()
        return false */
    }

    private fun hasUpper(text: String): Boolean{
        var letter = 'A'
        while (letter <= 'Z') {
            if(text[0] == letter){
                return true
            }
            ++letter
        }
        return false
    }

    private fun hasNumber(text: String): Boolean{
        for(i in 0..9){
            if(text.contains(i.toString())){
                return true
            }
        }
        return false
    }

    private fun hasSpecial(text: String): Boolean{
        val specialCharacters = "!@#$%?"
        for(special in specialCharacters){
            if(text.contains(special)){
                return true
            }
        }
        return false
    }




    }
